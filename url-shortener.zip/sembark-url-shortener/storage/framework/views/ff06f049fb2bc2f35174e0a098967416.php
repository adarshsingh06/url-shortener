<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> · URL Shortener</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="site-shell">
        <header class="topbar">
            <a class="brand" href="<?php echo e(auth()->check() ? route('dashboard') : route('login')); ?>" aria-label="Sembark URL Shortener home">
                <span class="brand-mark">↗URL Short</span>
            </a>
            <?php if(auth()->guard()->check()): ?>
                <div class="topbar-right">
                    <span class="signed-in"><?php echo e(auth()->user()->name); ?> <span class="role-chip"><?php echo e(auth()->user()->role); ?></span></span>
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="button button-quiet" type="submit">Log out <span aria-hidden="true">→</span></button>
                    </form>
                </div>
            <?php endif; ?>
        </header>

        <?php if(session('status')): ?>
            <div class="notice notice-success" role="status"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="notice notice-error" role="alert">
                <strong>Check the details below.</strong>
                <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
        <footer class="site-footer" style="text-align: center !importent"><span>&copy; 2026 URL SHORTENER </span></footer>
    </div>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp8.2\htdocs\sembark-url-shortener\resources\views/layouts/app.blade.php ENDPATH**/ ?>